.onLoad = function(library, pkg)
{
  if(interactive())
  {
    packageStartupMessage("# GGoutlieR v0.2.2")
  }

}
