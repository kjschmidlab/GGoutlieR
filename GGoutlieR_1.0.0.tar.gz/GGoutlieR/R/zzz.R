.onLoad = function(library, pkg)
{
  if(interactive())
  {
    packageStartupMessage("# Load GGoutlieR v1.0.0")
  }

}
